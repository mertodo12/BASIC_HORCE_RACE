# BASIC_HORCE_RACE
Merhaba,C# basit düzeyde bir at yarışı oyunu yaptım ve bu oyunu sizle kodları paylaşmak istedim.



Hi guys.I use c#.I created basic horse race
